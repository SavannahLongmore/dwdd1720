let x = new Date();
console.log(x);
let y = x.getFullYear();
console.log(y);
document.querySelector('#theYear').textContent = y;